﻿$(function () {
    var poking = false;
    var removeAds = function () {
        console.log('Ads : ',$('.ego_section h5 span').parents('.ego_section') );
        $('.ego_section h5 span').parents('.ego_section').remove();
    };
    var poke = function () {
        if (!poking) return;
        
        var pokeBack = $('a.uiIconText').filter(function (index, elem) {
            var content = new String( $(elem).html() );
            return /戳回去/.test(content);
        });
        console.log('pokeBack : ',pokeBack);
        for (var a = 0; a < pokeBack.length; a++) {
            pokeBack[a].click();
        }
    };
    var work = function () {
        removeAds();
        poke();
    };
    
    var togglePoke = function () {
        poking = !poking;
        if (poking) {
            $('#pokeSwitch > a').text('Poking!');
        } else {
            $('#pokeSwitch > a').text('No poke');
        }
        if ( !/pokes/.test(window.location.href) ) {
            window.location.replace('http://www.facebook.com/pokes');
        }
    };
    var addButtonOnBlueBar = function () {
        $('#navHome').after('<li class="navItem middleItem" id="pokeSwitch"><a>No poke</a></li>');
        $('#pokeSwitch').click(togglePoke);
    };
    $('body').click(work).keydown(work);
    work();
    addButtonOnBlueBar();
});